console.log(test1.toString());

function test1(){
    console.log("最开始的调用方法");
}