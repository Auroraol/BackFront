console.log("20">"100000");//true
console.log(null>2);//false
console.log(NaN>2);//false

//关系操作符
var testNum=3;
console.log("下面是关系操作符");
console.log(testNum==1);
console.log(testNum===1);
console.log(testNum!=1);
console.log(testNum>1);
console.log(testNum>=1);
console.log(testNum<1);
console.log(testNum<=1);