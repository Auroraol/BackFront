var times=123453;//求多少分，多少秒；
var targetTime=parseInt(times/60)+"分"+times%60+"秒";
console.log(targetTime);
//思考：等于多少天，多少小时，多少分，多少秒