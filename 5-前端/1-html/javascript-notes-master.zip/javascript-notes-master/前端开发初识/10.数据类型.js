console.log("22");//string 字符串
console.log(22);//number 数字类型
console.log(true);//boolean 布尔 英文考试了 T / F

console.log(undefined);
console.log(null);
console.log({});
console.log(function () {});