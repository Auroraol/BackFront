//        tb='淘宝';

var jd="京东商城";
//    var z="亚马逊';// 双引号" 和单引号' 不能混合使用
var xx;
/*
* var        variable 变量 let const  声明变量的关键字；
* tb         这是变量名
* =          这是操作符
* "京东商城"  这个是数据
*
* 把"京东商城"，这段数据，通过=来赋值给jd这个变量名；
* */
console.log(jd);
console.log(xx);//undefined
//    console.log(tb);

//"京东商城"  字符串"" 和 '' 包裹的内容 属于字符串类型