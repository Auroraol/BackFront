"use strict";

var oDiv2=document.getElementById("btn2");
oDiv2.onclick=function () {
    alert("这是外联时的写法；")
};