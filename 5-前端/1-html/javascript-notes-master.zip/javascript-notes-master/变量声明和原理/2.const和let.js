const myName="zhu";
let age=2;
age =22;
// myName=4;//Error
console.log(age);