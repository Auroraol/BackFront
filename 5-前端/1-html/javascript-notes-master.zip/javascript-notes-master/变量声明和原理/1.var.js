var name="朱安邦",
    gender;
console.log(name,typeof name);      //朱安邦 string
console.log(gender,typeof gender);  //undefined "undefined"