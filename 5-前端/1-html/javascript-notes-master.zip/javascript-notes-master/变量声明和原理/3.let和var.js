if(true){
    var a=2;
}
if(true){
    let b=3;
}
console.log(a);
console.log(b);//b is not defined