var jsonData = [
    {
        name: "朱安邦",
        age: 25,
        email: "1234567890@qq.com",
        phone: "13245637823",
        score: 1340
    },
    {
        name: "刘安邦",
        age: 23,
        email: "4123456780@qq.com",
        phone: "18723456423",
        score: 1200
    },
    {
        name: "李安邦",
        age: 32,
        email: "4123456890@qq.com",
        phone: "13800026574",
        score: 1800
    },
    {
        name: "王安邦",
        age: 41,
        email: "5234567890@qq.com",
        phone: "13800993302",
        score: 1034
    },
    {
        name: "甄安邦",
        age: 40,
        email: "2234567890@qq.com",
        phone: "15802193302",
        score: 1456
    },
    {
        name: "爱安邦",
        age: 34,
        email: "2234567890@qq.com",
        phone: "13411293302",
        score: 2568
    },
    {
        name: "殷安邦",
        age: 23,
        email: "1323467890@qq.com",
        phone: "17723493302",
        score: 1445
    },
    {
        name: "康安邦",
        age: 34,
        email: "4723467890@qq.com",
        phone: "13833493302",
        score: 1740
    },
    {
        name: "邓安邦",
        age: 43,
        email: "9123456890@qq.com",
        phone: "15922493302",
        score: 1890
    },
    {
        name: "朱一名",
        age: 25,
        email: "9123456890@qq.com",
        phone: "13846379824",
        score: 1190
    },
    {
        name: "朱二名",
        age: 28,
        email: "9123456890@qq.com",
        phone: "15934493302",
        score: 1290
    },
    {
        name: "朱三名",
        age: 28,
        email: "9123456890@qq.com",
        phone: "15956783302",
        score: 1490
    },
    {
        name: "朱四名",
        age: 38,
        email: "9123456890@qq.com",
        phone: "15922496538",
        score: 1990
    },
    {
        name: "朱五名",
        age: 48,
        email: "9123456890@qq.com",
        phone: "15922497890",
        score: 1290
    },
    {
        name: "朱六名",
        age: 37,
        email: "9123456890@qq.com",
        phone: "15922434562",
        score: 2890
    },
    {
        name: "朱七名",
        age: 25,
        email: "9123456890@qq.com",
        phone: "15922474529",
        score: 3790
    },
    {
        name: "朱八名",
        age: 26,
        email: "9123456890@qq.com",
        phone: "15922499457",
        score: 2390
    },
    {
        name: "朱九名",
        age: 34,
        email: "9123456890@qq.com",
        phone: "15922492536",
        score: 1290
    },
    {
        name: "朱十名",
        age: 23,
        email: "9123456890@qq.com",
        phone: "15922492648",
        score: 2890
    },
];