window._apiUrl = {
    // serverUrl: 'http://127.0.0.1:8080/',
    serverUrl: 'https://www.huhailong.vip/server/',
}