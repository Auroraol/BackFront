<template>
    <div class="resource">
        <el-empty description="正在开发中，敬请期待"></el-empty>
    </div>
</template>
<script>
export default {
    name: 'Resource',
    data(){return{}},
    methods:{},
    mounted(){}
}
</script>
<style lang="scss" scoped>
.resource{
    min-height: calc(100vh - 8rem);
}
</style>