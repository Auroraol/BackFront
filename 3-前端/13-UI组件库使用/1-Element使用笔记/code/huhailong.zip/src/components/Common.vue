<script>
const prePath = '/';
export default {
    prePath
}
</script>