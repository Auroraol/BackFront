package com.lfj.dao;

/**
 * @Author: LFJ
 * @Date: 2023-10-08 17:14
 */

public interface PersonDao {
	void getPerson();
}
