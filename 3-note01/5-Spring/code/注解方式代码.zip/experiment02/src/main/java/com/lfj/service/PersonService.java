package com.lfj.service;

/**
 * @Author: LFJ
 * @Date: 2023-10-08 17:08
 */

public interface PersonService {
	void getPerson();
}
