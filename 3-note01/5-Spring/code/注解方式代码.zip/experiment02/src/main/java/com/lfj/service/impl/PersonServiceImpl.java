package com.lfj.service.impl;

import com.lfj.dao.PersonDao;
import com.lfj.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: LFJ
 * @Date: 2023-10-08 22:10
 */

@Service("PersonServiceImpl")
//或者 @Component("PersonServiceImpl")
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonDao personDao;

	public void getPerson() {
		System.out.println("PersonServiceImpl......");
		personDao.getPerson();
	}
}
