package com.lfj.dao.impl;

import com.lfj.dao.PersonDao;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * @Author: LFJ
 * @Date: 2023-10-08 22:00
 */

@Repository()
@Scope(value = "prototype")
public class PersonDaoImpl implements PersonDao {
	public void getPerson() {
		System.out.println("PersonDao:getPerson");
	}
}
