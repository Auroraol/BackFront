package com.lfj.service.impl;

import com.lfj.dao.PersonDao;
import com.lfj.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: LFJ
 * @Date: 2023-10-08 21:14
 */

//Service报错
@Service("PersonServiceExt")
//或者 @Component("PersonServiceExt")
public class PersonServiceExt implements PersonService {

	@Autowired
	private PersonDao personDao;

	public void getPerson() {
		System.out.println("PersonServiceExt......");
		personDao.getPerson();
	}
}