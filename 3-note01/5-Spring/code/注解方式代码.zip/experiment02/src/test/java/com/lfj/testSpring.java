package com.lfj;

import com.lfj.service.PersonService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @Author: LFJ
 * @Date: 2023-10-08 21:29
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class testSpring {

	@Qualifier("PersonServiceExt")
	@Autowired
	PersonService personService1;

	@Qualifier("PersonServiceImpl")
	@Autowired
	PersonService personService2;

	@Test
	public void test1() {
		personService1.getPerson();
	}

	@Test
	public void test2() {
		personService2.getPerson();
	}
}
