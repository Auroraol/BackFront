package com.itheima.pojo;

public class User {
	private int  uid;             //�û�id
    private String uname;       //�û�����
    private int  uage;            //�û�����
    
    public int  getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public int  getUage() {
        return uage;
    }

    public void setUage(int uage) {
        this.uage = uage;
    }
}

