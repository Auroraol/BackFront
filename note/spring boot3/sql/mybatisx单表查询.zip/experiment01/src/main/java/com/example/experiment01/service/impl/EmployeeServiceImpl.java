package com.example.experiment01.service.impl;

import com.example.experiment01.entity.Employee;
import com.example.experiment01.service.EmployeeService;
import com.example.experiment01.mapper.EmployeeMapper;
import org.springframework.stereotype.Service;

/**
* @author 16658
* @description 针对表【employee】的数据库操作Service实现
* @createDate 2023-09-14 13:56:45
*/
@Service
public class EmployeeServiceImpl implements EmployeeService{

}




