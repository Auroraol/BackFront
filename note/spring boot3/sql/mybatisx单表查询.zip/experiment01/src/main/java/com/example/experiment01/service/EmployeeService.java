package com.example.experiment01.service;

import com.example.experiment01.entity.Employee;

/**
* @author 16658
* @description 针对表【employee】的数据库操作Service
* @createDate 2023-09-14 13:56:45
*/
public interface EmployeeService {

}
