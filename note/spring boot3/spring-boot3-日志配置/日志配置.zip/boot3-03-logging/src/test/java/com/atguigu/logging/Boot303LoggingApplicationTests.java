package com.atguigu.logging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot303LoggingApplicationTests {

    @Test
    void contextLoads() {
    }

}
