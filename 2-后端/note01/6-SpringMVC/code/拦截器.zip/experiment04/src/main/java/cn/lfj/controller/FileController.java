package cn.lfj.controller;

import cn.lfj.pojo.Resource;
import cn.lfj.utils.JSONFileUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author: LFJ
 * @Date: 2023-10-20 23:56
 */

@Controller
public class FileController {
	/**
	 * 文件上传
	 */
	@RequestMapping("fileload")
	public String fileLoad(MultipartFile[] files, HttpSession request) throws Exception {
		String path = request.getServletContext().getRealPath("/") + "files/";    //设置上传的文件所存放的路径
		//创建Jackson的ObjectMapper对象，用于对象和JSON的转换。
		ObjectMapper mapper = new ObjectMapper();
		if (files != null && files.length > 0) { //判断是否有上传的文件
			//循环获取上传的文件
			for (MultipartFile file : files) {  //遍历上传的文件
				//获取上传文件的名称
				String filename = file.getOriginalFilename();
				ArrayList<Resource> list = new ArrayList<>();  //创建一个Resource对象的集合，用于存储文件信息。
				// 文件夹中是否有同名文件
				//读取files.json文件中的文件名称
				String json = JSONFileUtils.readFile(path + "/files.json");
				if (json.length() != 0) {
					//将files.json的内容转为集合
					list = (ArrayList<Resource>) mapper.readValue(json, new TypeReference<List<Resource>>() {
					});
					for (Resource resource : list) {
						//如果上传的文件在files.json文件中有同名文件，将当前上传的文件重命名，以避免重名
						if (filename.equals(resource.getName())) {
							String[] split = filename.split("\\.");
							filename = split[0] + "(1)." + split[1];
						}
					}
				}
				// 设置文件保存的全路径
				String filePath = path + filename;
				// 保存上传的文件
				file.transferTo(new File(filePath));
				list.add(new Resource(filename));
				json = mapper.writeValueAsString(list); //将集合中转换成json
				//将上传文件的名称保存在files.json文件中
				JSONFileUtils.writeFile(json, path + "/files.json");
			}
			request.setAttribute("msg", "(上传成功)");
			return "forward:/fileload.jsp";
		}
		request.setAttribute("msg", "(上传失败)");
		return "forward:/fileload.jsp";
	}

	@ResponseBody
	@RequestMapping(value = "/getFilesName",
			produces = "text/html;charset=utf-8")
	public String getFilesName(HttpSession request,
							   HttpServletResponse response) throws Exception {
		String path = request.getServletContext().getRealPath("/") + "files/files.json";
		String json = JSONFileUtils.readFile(path);
		return json;
	}

	/**
	 * 根据浏览器的不同进行编码设置，返回编码后的文件名
	 */
	public String getFilename(HttpServletRequest request, String filename) throws Exception {
		// IE不同版本User-Agent 中出现的关键词
		String[] IEBrowserKeyWords = {"MSIE", "Trident", "Edge"};
		// 获取请求头代理信息
		String userAgent = request.getHeader("User-Agent");
		for (String keyWord : IEBrowserKeyWords) {
			if (userAgent.contains(keyWord)) {
				// IE内核浏览器，统一为UTF-8编码
				return URLEncoder.encode(filename, "UTF-8");
			}
		}
		// 火狐等其他浏览器统一为ISO-8859-1编码显示
		return new String(filename.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
	}

	/**
	 * 文件下载
	 */
	@RequestMapping("/download")
	public ResponseEntity<byte[]> fileDownload(HttpServletRequest request, String filename) throws Exception {
		// 指定要下载的文件所在路径
		String path = request.getSession().getServletContext().getRealPath("/files/");
		filename = new String(filename.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
		// 创建该文件对象
		File file = new File(path + File.separator + filename);
		// 设置响应头
		HttpHeaders headers = new HttpHeaders();
		// 对文件名编码，防止中文文件乱码
		filename = this.getFilename(request, filename);
		// 通知浏览器以下载的方式打开文件
		headers.setContentDispositionFormData("attachment", filename);
		// 定义以流的形式下载返回文件数据
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		// 使用Sring MVC框架的ResponseEntity对象封装返回下载数据
		return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file), headers, HttpStatus.OK);
	}

}
