package cn.lfj.pojo;

/**
 * @Author: LFJ
 * @Date: 2023-10-21 0:13
 */
public class Resource {
	private String name;                //name属性表示文件名称

	public Resource() {
	}

	public Resource(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

