package com.wd.demo.entity;

import lombok.Data;

@Data
public class Product {

    private Integer productId;
    private String productName;
    private Double productPrice;

}
