package cn.lfj.entity;

/**
 * @Author: LFJ
 * @Date: 2023-10-17 22:23
 */
public class Student {
	private String studentname;

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
}
