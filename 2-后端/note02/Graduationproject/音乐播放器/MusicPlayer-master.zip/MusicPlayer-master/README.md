# MusicPlayer
基于个性化推荐的音乐播放系统

Hi, 这是我在大四的时候做的毕设，现如今将该项目开源。
本项目是基于Python的tkinter和pygame所著。
该项目总体来说，代码比较烂（因为当时水平很菜）。
运行的话安装几个基本库就能跑，只不过里面的数据还没有上传至Github。
先写到这里，如果有人看的话再写。

如果你喜欢这个项目，麻烦点个Star，这是我第一个正式开源的项目！

Music playing system based on personalized recommendation

Hi, this is the final design I did when I was a student, and now the project is open source.
This project is based on Python's tkinter and pygame.
Generally speaking, the code of this project is rather bad (because the level is very low at the time).
If you run it, install a few basic libraries and you can run it, but the data in it has not been uploaded to Github.
Write it here first, and then write it if someone reads it.

If you like this project, please order Star, this is my first officially open source project!

![image](https://user-images.githubusercontent.com/58715113/136698123-00a0ef09-d1a2-4e01-b527-6e36468fd09b.png)
