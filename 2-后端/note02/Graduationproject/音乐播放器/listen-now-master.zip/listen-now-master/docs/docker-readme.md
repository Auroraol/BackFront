* 整个免配置docker版本正在准备, 后期你就可以直接下载体验, 它装好了所有环境并且使用Nginx和uwsgi来配置, 而不是使用flask的debug模块
