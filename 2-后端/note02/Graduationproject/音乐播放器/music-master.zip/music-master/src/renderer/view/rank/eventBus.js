export default {
    list: Array(22).fill(null),
    renderCache: null,
}
