export default new Vue({
  data() {
    return {
      searchResult: []
    }
  }
})