export default {
    banner: {
        list: [],
        cache: null
    },
    playlist: {
        list: [],
        chosen: '华语'
    }
}