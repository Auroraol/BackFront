from django.apps import AppConfig


class MusicConfig(AppConfig):
    name = 'music'
    default_auto_field = 'django.db.models.BigAutoField'
