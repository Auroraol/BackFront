# card-button

card-button组件

## 使用方法
```
import cardButton from '../components/common/cardButton/cardButton';

<card-button type="ios-paperplane"  //  图标，参考iview的图标 
             size="50"  //  按钮大小，默认60
             color="green"  //  按钮的颜色，默认pink
             v-on:click-button="test()" //  点击发生时的事件
             text="1234">   //  显示文字
</card-button>
```
