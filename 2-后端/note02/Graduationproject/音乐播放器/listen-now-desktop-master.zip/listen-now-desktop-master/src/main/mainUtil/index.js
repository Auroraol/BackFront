//  这里是用以存放主进程一些Util的地方
function example() {
  return 0;
}
module.exports = {
  ex: example,
};
