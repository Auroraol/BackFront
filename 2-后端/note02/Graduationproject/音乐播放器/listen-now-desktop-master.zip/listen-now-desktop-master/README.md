# listen-now-desktop

listen-now 的桌面版
![首页](designs/Listen-now_首页.jpg)
![正在播放](designs/Listen-now_正在播放页.jpg)
![歌单页](designs/Listen-now_歌单页.jpg)
![搜索页](designs/Listen-now_搜索页.jpg)

## 开发状况

目前处于第一个阶段的开发中，开发进度我们会随时进行更新。

## 了解项目

关于项目的一些可能用到的文档，在docs文件夹中。

## 贡献我们

本项目采用Pull Request工作流，详细贡献方式请见docs中贡献指南文档

## 安装

