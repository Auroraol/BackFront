# 网易云音乐 API

> 网易云音乐 NodeJS 版 API

- 全部接口已升级到最新
- 具备登录接口,多达200多个接口
- 更完善的文档


[GitHub](https://github.com/Binaryify/NeteaseCloudMusicApi)
[Get Started](#neteasecloudmusicapi)

![color](#ffffff)
