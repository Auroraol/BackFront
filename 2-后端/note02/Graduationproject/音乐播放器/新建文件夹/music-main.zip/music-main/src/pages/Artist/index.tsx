import React from 'react';

interface Props {}

const Artist: React.FC<Props> = () => {
  return <div>Working in progress</div>;
};

export default Artist;
