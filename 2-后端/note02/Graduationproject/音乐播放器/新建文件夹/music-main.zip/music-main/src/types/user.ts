export interface IUser {
  nickname: string;
  avatarUrl: string;
  userId: number;
  signature: string;
  id: number;
  vipType: number;
}
