export type PlayStatus = 'playing' | 'paused';
