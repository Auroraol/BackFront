# Music

基于网易云音乐API的Web音乐播放器

[Demo](https://music.maoyu.space)

![image](https://github.com/user-attachments/assets/79addcdd-2029-46ae-b959-c7946d510c51)

## 功能特性

- 响应式设计，支持移动设备
- 歌词展示，实现逐字歌词效果
- 歌曲评论
- 个人歌单
- 每日推荐
- 动态展示
- TODO

