<script setup lang="ts">
</script>

<template>
<div>Music Player</div>
</template>