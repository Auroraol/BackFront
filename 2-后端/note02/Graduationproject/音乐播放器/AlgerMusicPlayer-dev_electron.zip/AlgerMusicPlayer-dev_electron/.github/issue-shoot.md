## IssueShoot
- 预估时长: {{ .duration }}
- 期望完成时间: {{ .deadline }}
- 开发难度: {{ .level }}
- 参与人数: 1
- 需求对接人: ivringpeng
- 验收标准: 实现期望改造效果，提 PR 并通过验收无误
- 备注: 最终激励以实际提交 `pull request` 并合并为准
