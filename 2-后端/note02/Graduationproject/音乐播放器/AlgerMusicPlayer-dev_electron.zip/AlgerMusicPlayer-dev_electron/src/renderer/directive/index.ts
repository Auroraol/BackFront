import { vLoading } from './loading/index';

const directives = {
  loading: vLoading
};

export default directives;
