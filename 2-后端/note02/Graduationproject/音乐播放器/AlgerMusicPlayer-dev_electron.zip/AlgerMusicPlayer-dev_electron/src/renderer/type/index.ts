export interface IData<T> {
  code: number;
  data: T;
  result: T;
}
