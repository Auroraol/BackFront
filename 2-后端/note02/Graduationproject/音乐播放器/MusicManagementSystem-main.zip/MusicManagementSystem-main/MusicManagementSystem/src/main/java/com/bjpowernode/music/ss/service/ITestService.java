/** 
* 
*
*
*/

package com.bjpowernode.music.ss.service;

import com.bjpowernode.music.common.IServiceOperations;
import com.bjpowernode.music.ss.domain.Test;

public interface ITestService extends IServiceOperations<Test, Test> {

}
