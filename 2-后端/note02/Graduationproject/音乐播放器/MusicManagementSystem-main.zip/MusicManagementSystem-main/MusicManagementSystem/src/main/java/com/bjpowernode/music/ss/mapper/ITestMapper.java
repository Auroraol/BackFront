/** 
* 
*
*
*/  

package com.bjpowernode.music.ss.mapper;
import com.bjpowernode.music.ss.domain.Test;
import com.bjpowernode.music.common.IOperations;

public interface ITestMapper extends IOperations<Test, Test> {
	
}

