## 修复优化

修复 Windows 10 GameBar 无法正确透明的bug
