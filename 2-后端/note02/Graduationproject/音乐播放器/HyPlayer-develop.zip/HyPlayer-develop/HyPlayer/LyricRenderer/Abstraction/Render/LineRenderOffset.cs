﻿namespace HyPlayer.LyricRenderer.Abstraction.Render;

public class LineRenderOffset
{
    public float X { get; set; }
    public float Y { get; set; }
}