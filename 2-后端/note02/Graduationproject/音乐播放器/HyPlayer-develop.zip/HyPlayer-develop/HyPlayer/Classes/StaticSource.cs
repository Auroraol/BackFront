﻿namespace HyPlayer.Classes;

internal static class StaticSource
{
    public static string PICSIZE_AUDIO_PLAYER_COVER = "640x640";
    public static string PICSIZE_IMMERSIVEMODE_COVER = "1024y1024";
    public static string PICSIZE_PLAYLIST_ITEM_COVER = "250y250";
    public static string PICSIZE_SIMPLE_LINER_LIST_ITEM = "250y250";
    public static string PICSIZE_SINGLENCSONG_COVER = "75y75";
    public static string PICSIZE_COMMENTUSER_AVATAR = "70y70";
    public static string PICSIZE_SONGLIST_DETAIL_COVER = "250y250";
    public static string PICSIZE_ARTIST_DETAIL_COVER = "250y250";
    public static string PICSIZE_SINGLENCALBUM_COVER = "70y70";
    public static string PICSIZE_SINGLENCRADIO_COVER = "70y70";
    public static string PICSIZE_SINGLENCPLAYLIST_COVER = "70y70";
    public static string PICSIZE_SINGLENCSINGER_COVER = "70y70";
    public static string PICSIZE_DOWNLOAD_ALBUMCOVER = "640y640";
    public static string PICSIZE_NAVITEM_USERAVATAR = "30y30";
}