# HyPlayer 效果预览 - 暗色

**歌单页面**

![歌单页面](Assets/SongList.png)

**歌词页面**

![歌词页面](Assets/ExpandedPlayer.png)

**主页**

![主页](Assets/HomePage.png)

**用户页面**

![用户页面](Assets/UserPage.png)

**搜索页面**

![搜索页面](Assets/Search.png)

**小窗播放**

![小窗播放](Assets/CompactPlayer.png)

**Toast 歌词**

![Toast 歌词](Assets/ToastLyric.png)

****

> 截图时版本号 2.1.15.0
>
> Designed by [aaaaaaccd](https://github.com/aaaaaaccd) & [kengwang](https://github.com/kengwang)

