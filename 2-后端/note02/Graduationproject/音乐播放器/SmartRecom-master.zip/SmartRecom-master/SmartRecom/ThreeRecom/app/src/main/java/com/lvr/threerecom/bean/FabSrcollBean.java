package com.lvr.threerecom.bean;

/**
 * Created by lvr on 2017/4/23.
 */

public class FabSrcollBean {
    private  boolean isTop;
    public boolean isTop() {
        return isTop;
    }

    public void setTop(boolean top) {
        isTop = top;
    }


}
