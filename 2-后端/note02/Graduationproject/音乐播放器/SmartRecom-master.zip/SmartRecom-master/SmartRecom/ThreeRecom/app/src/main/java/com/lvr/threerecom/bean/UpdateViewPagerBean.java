package com.lvr.threerecom.bean;

/**
 * Created by lvr on 2017/5/11.
 */

public class UpdateViewPagerBean
{
    public boolean isUpdate() {
        return isUpdate;
    }

    public void setUpdate(boolean update) {
        isUpdate = update;
    }

    private boolean isUpdate;
}
