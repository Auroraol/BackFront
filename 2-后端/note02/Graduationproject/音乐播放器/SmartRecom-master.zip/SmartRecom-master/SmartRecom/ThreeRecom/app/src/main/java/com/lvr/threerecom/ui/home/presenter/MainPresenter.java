package com.lvr.threerecom.ui.home.presenter;

/**
 * Created by lvr on 2017/4/24.
 */

public interface MainPresenter {
    void requestHotMoviee();
}
