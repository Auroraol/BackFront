package com.lvr.threerecom.ui.music.presneter;

/**
 * Created by lvr on 2017/4/26.
 */

public interface MusicPresenter {
    void requestSongListAll(String format, String from, String method, int page_size, int page_no);

}
