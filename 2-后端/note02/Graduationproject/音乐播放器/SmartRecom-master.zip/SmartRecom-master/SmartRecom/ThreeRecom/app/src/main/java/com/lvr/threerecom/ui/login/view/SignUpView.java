package com.lvr.threerecom.ui.login.view;

/**
 * Created by lvr on 2017/5/19.
 */

public interface SignUpView {
    void returnSignUpResult(boolean result);
}
