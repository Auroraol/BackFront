package com.lvr.threerecom.ui.movie.view;

/**
 * Created by lvr on 2017/5/19.
 */

public interface MovieJudgeView {
    void returnJudegeResult(boolean result);
}
