package com.lvr.threerecom.ui.login.presenter;

/**
 * Created by lvr on 2017/5/19.
 */

public interface SignUpPresenter {
    void requestSignUp(String username, String password);
}
