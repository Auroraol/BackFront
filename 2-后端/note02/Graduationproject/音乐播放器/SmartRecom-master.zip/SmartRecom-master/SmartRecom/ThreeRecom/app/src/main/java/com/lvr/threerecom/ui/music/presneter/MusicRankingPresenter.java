package com.lvr.threerecom.ui.music.presneter;

/**
 * Created by lvr on 2017/4/27.
 */

public interface MusicRankingPresenter {
    void requestRankingListAll(String format,String from,String method, int kflag);
}
