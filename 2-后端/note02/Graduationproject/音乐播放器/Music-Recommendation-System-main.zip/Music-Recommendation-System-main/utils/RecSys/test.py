# 测试工具
import mysql_util

# 测试连接
# mysql_util.test_connect()

# # 测试读取用户信息到数据库中
# mysql_util.read_user_info2mysql()
#
# # 测试读取歌手信息到数据库中
# mysql_util.read_singer_info2mysql()

# # 测试读取歌曲信息到数据库中
# mysql_util.read_song_info2mysql()
#
# # 测试读取用户播放记录到数据库中
# mysql_util.read_record2mysql()
#
# # 测试读取topN_users到数据库中
# mysql_util.read_top_users2mysql()
#
# # 测试读取topN_songs到数据库中
# mysql_util.read_top_songs2mysql()
#
# # 测试更新数据库中song表的下载链接
# mysql_util.set_songs_down_url()

# 测试更新数据中的播放时长和图片
# mysql_util.set_songs_time_picRlr()

# 测试更新歌曲发行时间
# mysql_util.set_songs_publish_time()

# # 更新用户信息
# mysql_util.update_user_info()
