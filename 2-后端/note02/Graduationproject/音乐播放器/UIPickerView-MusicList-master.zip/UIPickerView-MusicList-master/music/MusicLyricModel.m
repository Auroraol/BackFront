//
//  MusicLyricModel.m
//  MusicPlayer
//
//  Created by 李志强 on 15/10/6.
//  Copyright (c) 2015年 李志强. All rights reserved.
//

#import "MusicLyricModel.h"

@implementation MusicLyricModel

@end
