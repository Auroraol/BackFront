//
//  LocalMusicSpeView.h
//  music
//
//  Created by autobot on 16/1/26.
//  Copyright © 2016年 autobot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocalMusicSpeView : UIView
- (void)startPlay;
- (void)stopPlay;
@end
