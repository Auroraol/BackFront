//
//  MusicLyricModel.h
//  MusicPlayer
//
//  Created by 李志强 on 15/10/6.
//  Copyright (c) 2015年 李志强. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicLyricModel : NSObject
@property (nonatomic, strong) NSString *lyricTime; //歌词时间
@property (nonatomic, strong) NSString *lyricStr;  //歌词
@end
