//
//  LocalMusicLyricCell.h
//  music
//
//  Created by enoughpower on 16/1/31.
//  Copyright © 2016年 autobot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocalMusicLyricCell : UITableViewCell
@property (nonatomic, strong)NSString *lyric;
@end
