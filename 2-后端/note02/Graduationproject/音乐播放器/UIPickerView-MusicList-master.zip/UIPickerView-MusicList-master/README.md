# UIPickerView-MusicList
基于自定义pickerView实现个性化音乐播放列表

* 简单的实现音乐播放器基本功能
* 上一曲，下一曲，歌词，专辑图片
* pickerView拖拽换歌
* 音乐列表，歌词界面切换


## 截图
![screen](http://ac-j38u14vo.clouddn.com/a041e72e8674852e.png)

