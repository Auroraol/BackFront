package com.coolrandy.com.coolmusicplayer.activity;

import android.app.Activity;
import android.os.Bundle;

import com.coolrandy.com.coolmusicplayer.R;

/**
 * Created by admin on 2016/3/3.
 */
public class TestActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scroller_view_layout);
    }
}
