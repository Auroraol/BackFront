package com.coolrandy.com.coolmusicplayer.manager;

/**
 * Created by admin on 2016/1/26.
 */
public class MusicPlayerManager {
}
