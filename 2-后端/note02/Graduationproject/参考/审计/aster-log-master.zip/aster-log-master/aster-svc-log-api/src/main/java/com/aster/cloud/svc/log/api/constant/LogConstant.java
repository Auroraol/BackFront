package com.aster.cloud.svc.log.api.constant;

/**
 * @author 王骞
 * @date 2021-01-11
 */
public interface LogConstant {

    /**
     * 服务名称
     */
    String SERVICE_NAME = "aster-svc-log";

}
