package com.aster.cloud.svc.log.api.dto;


import com.aster.cloud.svc.log.api.entity.BizLog;

/**
 * @author 王骞
 * @date 2021-01-12
 */
public class BizLogDTO extends BizLog {
}
