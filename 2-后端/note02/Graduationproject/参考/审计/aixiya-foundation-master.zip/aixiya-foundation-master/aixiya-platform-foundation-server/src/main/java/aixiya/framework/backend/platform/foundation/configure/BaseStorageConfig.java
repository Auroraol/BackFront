package aixiya.framework.backend.platform.foundation.configure;

/**
 * @Author wangqun865@163.com
 */
public interface BaseStorageConfig {
}
