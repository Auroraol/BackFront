package aixiya.framework.backend.platform.foundation.mapper;

import aixiya.framework.backend.platform.foundation.entity.SmsSendLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * @Author wangqun865@163.com
 */

public interface SmsSendLogMapper extends BaseMapper<SmsSendLog> {

}
