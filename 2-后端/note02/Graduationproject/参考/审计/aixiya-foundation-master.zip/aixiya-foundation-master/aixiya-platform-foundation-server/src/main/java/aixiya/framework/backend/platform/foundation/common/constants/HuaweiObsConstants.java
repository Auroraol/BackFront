package aixiya.framework.backend.platform.foundation.common.constants;

/**
 * @Author wangqun865@163.com
 */
public class HuaweiObsConstants {

    public static final String[] IMG_TYPES = new String[]{".jpg", ".jpeg", ".png", ".bmp", ".webp", ".gif", ".tiff"};
}
