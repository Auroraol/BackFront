wspush
======

把guacamole服务端返回的消息存储为文本文件，用wspush这个项目来回放，用于审计
