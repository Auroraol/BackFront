import { createStore } from 'vuex'
//import user from './modules/user'



const store = createStore({
    state:{
    }
})

export default store
