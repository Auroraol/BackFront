一个基于Go+Vue3做的前后端分离网盘项目。
![输入图片说明](image.png)
![输入图片说明](image2.png)
![输入图片说明](image3.png)
![输入图片说明](image4.png)