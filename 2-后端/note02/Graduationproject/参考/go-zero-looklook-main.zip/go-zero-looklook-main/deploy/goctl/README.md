# CN
项目使用额goctl模版，
可以自己替换

# EN
The GOCTL template used in the project, can be customized per your need.
