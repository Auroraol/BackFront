package config

//wechat mini config
type WxMiniConf struct {
	AppId  string `json:"AppId"`  //wechat mini appId
	Secret string `json:"Secret"` //wechat mini secret
}
