package uniqueid

import "testing"

func TestGenSn(t *testing.T) {
	GenSn(SN_PREFIX_HOMESTAY_ORDER)
}
