import { BaseService, Service, Permission } from "@/common/cl-admin";

@Service("goods/category")
class GoodsCategory extends BaseService {}

export default GoodsCategory;
