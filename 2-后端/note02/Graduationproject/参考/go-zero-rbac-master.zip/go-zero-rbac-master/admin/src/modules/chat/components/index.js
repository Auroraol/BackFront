import Notice from "./notice";
import Chat from "./chat";

export default { Notice, Chat };
