import Info from "./info";

export default {
	task: {
		info: new Info()
	}
};
