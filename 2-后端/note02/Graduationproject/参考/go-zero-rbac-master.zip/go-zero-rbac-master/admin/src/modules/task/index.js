import service from "./service";

export default { service };
