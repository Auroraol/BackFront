import service from "./service";
import components from "./components";
import filters from "./filters";

export default { components, service, filters };
