import { BaseService, Service } from "@/common/cl-admin";

@Service("sys/menu")
class SysMenu extends BaseService {}

export default SysMenu;
