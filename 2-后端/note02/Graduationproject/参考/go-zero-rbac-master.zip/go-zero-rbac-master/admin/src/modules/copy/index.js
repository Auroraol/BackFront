import copy from "./directives";

export default {
	directives: {
		copy
	}
};
