import Upload from "./index.vue";
import UploadSpace from "./space/index.vue";

export default {
	Upload,
	UploadSpace
};
