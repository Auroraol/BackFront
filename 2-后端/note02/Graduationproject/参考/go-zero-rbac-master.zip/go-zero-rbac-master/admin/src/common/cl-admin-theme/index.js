import components from "./components";

export default { components };
