<!--
  - # 文件：fans.vue  项目：aso-zero
  - # 作用：
  - # 当前修改时间：2021年07月24日 22:50:28
  - # 上次修改时间：2021年07月24日 22:50:27
  - # 作者：thunur
  - # 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用。
  - # 任何企业和个人不允许对程序代码以任何形式任何目的再发布。
  - # 如果您还没获得授权请联系我们 thunur@qq.com
  - # Copyright (c) 2021 aso.design
  -->

<template>
	<!-- todo 待开发 -->
</template>

<script>
export default {
	name: "fans"
};
</script>

<style scoped></style>
