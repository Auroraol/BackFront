import { BaseService, Service, Permission } from "@/common/cl-admin";

@Service("goods")
class Goods extends BaseService {}

export default Goods;
