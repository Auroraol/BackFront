import components from "./components";
import service from "./service";
import store from "./store";

export default { components, service, store };
