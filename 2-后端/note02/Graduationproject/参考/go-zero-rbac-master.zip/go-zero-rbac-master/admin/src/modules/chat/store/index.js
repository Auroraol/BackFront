import session from "./session";
import message from "./message";

export default {
	session,
	message
};
