import Theme from "./theme";

export default {
	Theme
};
