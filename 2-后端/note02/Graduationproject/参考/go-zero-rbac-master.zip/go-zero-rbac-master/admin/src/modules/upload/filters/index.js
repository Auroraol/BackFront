import { video_poster, image_resize } from "./oss";

export default {
	video_poster,
	image_resize
};
