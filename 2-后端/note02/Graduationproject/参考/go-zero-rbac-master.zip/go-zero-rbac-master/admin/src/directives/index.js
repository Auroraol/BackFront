import permission, { checkPerm } from "./permission";

export { checkPerm };

export default {
	permission
};
