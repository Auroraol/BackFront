import { BaseService, Service } from "@/common/cl-admin";

@Service("system/param")
class SysParam extends BaseService {}

export default SysParam;
