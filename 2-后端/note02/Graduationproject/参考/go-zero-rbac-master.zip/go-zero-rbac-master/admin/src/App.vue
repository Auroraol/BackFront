<template>
	<div id="app">
		<router-view />
	</div>
</template>

<style lang="scss" src="./assets/css/index.scss"></style>
