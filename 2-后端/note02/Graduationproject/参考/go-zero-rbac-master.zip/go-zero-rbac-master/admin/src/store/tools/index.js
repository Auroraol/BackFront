import user from "./user";
import app from "./app";
import process from "./process";
import module from "./module";
import menu from "./menu";

export default { user, app, process, module, menu };
