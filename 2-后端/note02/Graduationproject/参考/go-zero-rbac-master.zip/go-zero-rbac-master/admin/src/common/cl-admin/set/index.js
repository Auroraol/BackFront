import SET_SERVICE from "./service";
import SET_ROUTER from "./router";
import SET_MODULE from "./module";

export { SET_SERVICE, SET_ROUTER, SET_MODULE };
