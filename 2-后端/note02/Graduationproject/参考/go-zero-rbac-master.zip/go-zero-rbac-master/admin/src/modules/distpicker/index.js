import Distpicker from "./components";

export default {
	components: {
		Distpicker
	}
};
