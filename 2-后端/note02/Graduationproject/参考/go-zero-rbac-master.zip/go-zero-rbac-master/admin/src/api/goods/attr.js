import { BaseService, Service, Permission } from "@/common/cl-admin";

@Service("goods/attr")
class GoodsAttr extends BaseService {}

export default GoodsAttr;
