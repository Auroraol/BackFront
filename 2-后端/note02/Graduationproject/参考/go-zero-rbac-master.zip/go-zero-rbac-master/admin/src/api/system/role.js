import { BaseService, Service } from "@/common/cl-admin";

@Service("sys/role")
class SysRole extends BaseService {}

export default SysRole;
