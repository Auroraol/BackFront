import BaseService from "./base";
import { Service, Permission } from "./desorator";

export { BaseService, Service, Permission };
