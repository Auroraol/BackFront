package com.common.manager;

public interface BaseManager {
}
