package com.anhuay.common.utils;

public class Base64Utils {
	
}
