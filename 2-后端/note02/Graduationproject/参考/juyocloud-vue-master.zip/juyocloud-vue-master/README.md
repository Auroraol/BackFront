## 橘柚个人云盘系统（前端）
大三毕业设计作品，基于 VUE3 + Element Plus

## 预览
![](media/img.png)
![](media/img_1.png)
![](media/img_2.png)
![](media/img_3.png)
![](media/img_4.png)

## 基本功能
* 基础操作：文件/文件夹上传、下载、重命名、删除
* 文件分享
* 文件夹加密
* 支持多种存储源