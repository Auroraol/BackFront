import { App } from 'vue'

// animate 动画样式
import 'animate.css/animate.min.css' //引入

export default (app: App) => {}
