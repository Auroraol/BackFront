import { App } from 'vue'
import 'virtual:svg-icons-register'

export default (app: App) => {}
