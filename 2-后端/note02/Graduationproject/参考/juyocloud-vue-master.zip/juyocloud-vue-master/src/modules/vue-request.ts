import { App } from 'vue'
import { setGlobalOptions } from 'vue-request'

setGlobalOptions({})

export default (app: App) => {}
