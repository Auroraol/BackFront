<template>
	<div class="p-5 w-full h-[75vh]">
		<el-skeleton animated count="5"> </el-skeleton>
	</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
