<template>
	<div class="w-full h-full">
		<el-skeleton animated>
			<template #template>
				<el-skeleton-item variant="p" class="!w-1/4"></el-skeleton-item>
				<br />
				<el-skeleton-item variant="p" class="!w-1/2"></el-skeleton-item>
			</template>
		</el-skeleton>
	</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
