<template>
	<basic-setting></basic-setting>
</template>

<script setup>
import BasicSetting from '@/pages/admin/download-link/basic-setting.vue'
</script>

<route lang="yaml">
meta:
  layout: admin
  name: 直链设置
</route>
