<template>
  recyclebin
</template>

<script>
export default {
  name: "index"
}
</script>

<style scoped>

</style>
<route lang="yaml">
meta:
  layout: Layout
</route>