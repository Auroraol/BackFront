<template>
	<index></index>
</template>

<script setup>
import Index from '@/pages/admin/storage-edit/index.vue'
</script>

<route lang="yaml">
meta:
  layout: admin
  name: 编辑存储源
</route>
