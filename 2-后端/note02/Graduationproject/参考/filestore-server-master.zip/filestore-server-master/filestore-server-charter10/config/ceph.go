package config

const (
	// CephAccessKey : 访问Key
	CephAccessKey = "PFEA7NXWXSOWVTFA16C9"
	// CephSecretKey : 访问密钥
	CephSecretKey = "cf3dwPMeadGbtEgwFUEA6emRVrVfDHpv0pLXFYby"
	// CephGWEndpoint : gateway地址
	CephGWEndpoint = "http://<你的rgw_host>:<<你的rgw_port>>"
)
