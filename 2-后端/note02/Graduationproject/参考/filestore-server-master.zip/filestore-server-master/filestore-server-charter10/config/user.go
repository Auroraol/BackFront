package config

const (
	// PasswordSalt : 加密盐
	// 更严格来说， 加密盐可以存放在数据库中，每个用户加密盐不一样
	PasswordSalt = "*#890"
)
