package config

// UploadEntry : 配置上传入口地址
var UploadEntry = "localhost:28080"

// UploadServiceHost : 上传服务监听的地址
var UploadServiceHost = "0.0.0.0:28080"
