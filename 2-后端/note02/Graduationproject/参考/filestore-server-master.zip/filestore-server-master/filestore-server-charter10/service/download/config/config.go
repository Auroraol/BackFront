package config

// UploadEntry : 配置上传入口地址
var DownloadEntry = "localhost:38080"

// DownloadServiceHost : 上传服务监听的地址
var DownloadServiceHost = "0.0.0.0:38080"
