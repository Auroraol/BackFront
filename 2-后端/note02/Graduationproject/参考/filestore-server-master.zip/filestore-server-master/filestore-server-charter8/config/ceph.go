package config

const (
	// CephAccessKey : 访问Key
	CephAccessKey = "8WOOFAOAZ3SKQK3Y5I2L"
	// CephSecretKey : 访问密钥
	CephSecretKey = "syYWcEmF0Dx7BXrpyDvuAZ3yRe4EmNC9oDrucx3M"
	// CephGWEndpoint : gateway地址
	CephGWEndpoint = "http://127.0.0.1:9080"
)
