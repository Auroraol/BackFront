package cn.lfj.bean;

import lombok.Data;

/**
 * bean对象
 */
@Data
public class User {
	private String username;
	private Integer age;
}
