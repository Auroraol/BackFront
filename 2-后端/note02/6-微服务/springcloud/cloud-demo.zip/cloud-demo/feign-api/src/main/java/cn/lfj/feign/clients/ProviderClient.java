package cn.lfj.feign.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 * @author: LFJ
 * @Date:  2024-04-11 12:11
 */

@FeignClient(value = "provider-service")
public interface ProviderClient {

    @GetMapping("/hello")
    String sayHello();
}

