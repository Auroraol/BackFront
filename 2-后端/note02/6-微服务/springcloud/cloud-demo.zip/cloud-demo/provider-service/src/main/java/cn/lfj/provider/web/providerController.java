package cn.lfj.provider.web;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
public class providerController {

    @GetMapping("/hello")
    String  sayHello(){
        return  "hello Feign!   032141226 刘丰洁";
    }
}