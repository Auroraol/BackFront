package com.github.xiaolyuh.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LayeringCacheWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(LayeringCacheWebApplication.class, args);
    }
}
