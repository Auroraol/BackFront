package com.example.redisredlock.dao;

import com.example.redisredlock.base.BaseDao;
import com.example.redisredlock.bean.Order;

/**
 * 订单dao
 */
public interface OrderDao extends BaseDao<Order, String> {


}
