package com.zhulang.xfxhsimple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author 狐狸半面添
 * @create 2023-09-20 1:42
 */
@SpringBootApplication
public class XfXhApplication {
    public static void main(String[] args) {
        SpringApplication.run(XfXhApplication.class, args);
    }
}
