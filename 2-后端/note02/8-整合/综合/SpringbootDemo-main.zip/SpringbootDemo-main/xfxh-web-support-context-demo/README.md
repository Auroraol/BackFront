# 讯飞星火大模型后端接口

启动项目后，直接使用 GET 请求访问 http://localhost:8080/test/sendQuestion?question=hello&id=2

讯飞官方web文档：https://www.xfyun.cn/doc/spark/Web.html