package com.fox.es_canal.constant;

/**
 * @author 狐狸半面添
 * @create 2023-03-31 3:41
 */
public class BlogConstants {
    /**
     * 每页搜索最多15条
     */
    public static final int SEARCH_PAGE_NUM = 15;
}
